from flask import Blueprint, request, jsonify
from models.startup import Startup
from models.startUpMember import StartupMember
from app.extensions import db
from app.utils.helper import error_response, success_response, paginate

startups_bp = Blueprint('startups', __name__, url_prefix='/api/startups')

@startups_bp.route('', methods=['GET'])
def get_startups():
    """Get all startups with filtering"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    industry = request.args.get('industry', type=str)
    stage = request.args.get('stage', type=str)
    search = request.args.get('search', type=str)
    
    query = Startup.query
    
    if industry:
        query = query.filter(Startup.industry.ilike(f'%{industry}%'))
    if stage:
        query = query.filter(Startup.stage == stage)
    if search:
        query = query.filter(
            (Startup.name.ilike(f'%{search}%')) |
            (Startup.description.ilike(f'%{search}%'))
        )
    
    result = paginate(query, page, per_page)
    
    return success_response({
        'startups': [startup.to_dict() for startup in result['items']],
        'pagination': result['pagination']
    })

@startups_bp.route('/<int:startup_id>', methods=['GET'])
def get_startup(startup_id):
    """Get single startup by ID"""
    startup = Startup.query.get(startup_id)
    if not startup:
        return error_response('Startup not found', 404)
    
    # Increment views
    startup.increment_views()
    
    return success_response({'startup': startup.to_dict()})

@startups_bp.route('', methods=['POST'])
def create_startup():
    """Create new startup"""
    data = request.get_json()
    
    required_fields = ['name', 'industry', 'creator_id', 'creator_first_name', 'creator_last_name']
    if not all(field in data for field in required_fields):
        return error_response('Missing required fields')
    
    # Check if startup name already exists
    if Startup.query.filter_by(name=data['name']).first():
        return error_response('Startup name already exists', 409)
    
    try:
        startup = Startup(
            name=data['name'],
            industry=data['industry'],
            location=data.get('location'),
            description=data.get('description'),
            stage=data.get('stage', 'idea'),
            creator_id=data['creator_id'],
            creator_first_name=data['creator_first_name'],
            creator_last_name=data['creator_last_name']
        )
        
        db.session.add(startup)
        db.session.commit()
        
        # Add creator as first member
        startup.add_member(
            data['creator_id'],
            data['creator_first_name'],
            data['creator_last_name'],
            'founder'
        )
        
        return success_response({'startup': startup.to_dict()}, 'Startup created successfully', 201)
    except Exception as e:
        db.session.rollback()
        return error_response(f'Failed to create startup: {str(e)}', 500)

@startups_bp.route('/<int:startup_id>', methods=['PUT'])
def update_startup(startup_id):
    """Update startup"""
    startup = Startup.query.get(startup_id)
    if not startup:
        return error_response('Startup not found', 404)
    
    data = request.get_json()
    
    try:
        if 'name' in data:
            startup.name = data['name']
        if 'industry' in data:
            startup.industry = data['industry']
        if 'location' in data:
            startup.location = data['location']
        if 'description' in data:
            startup.description = data['description']
        if 'stage' in data:
            startup.update_stage(data['stage'])
        if 'positions' in data:
            startup.positions = data['positions']
        
        db.session.commit()
        return success_response({'startup': startup.to_dict()}, 'Startup updated successfully')
    except Exception as e:
        db.session.rollback()
        return error_response(f'Failed to update startup: {str(e)}', 500)

@startups_bp.route('/<int:startup_id>/members', methods=['GET'])
def get_startup_members(startup_id):
    """Get startup members"""
    startup = Startup.query.get(startup_id)
    if not startup:
        return error_response('Startup not found', 404)
    
    members = startup.get_active_members()
    return success_response({
        'members': [member.to_dict() for member in members]
    })

@startups_bp.route('/<int:startup_id>/members', methods=['POST'])
def add_startup_member(startup_id):
    """Add member to startup"""
    startup = Startup.query.get(startup_id)
    if not startup:
        return error_response('Startup not found', 404)
    
    data = request.get_json()
    required_fields = ['user_id', 'first_name', 'last_name']
    if not all(field in data for field in required_fields):
        return error_response('Missing required fields: user_id, first_name, last_name')
    
    try:
        startup.add_member(
            data['user_id'],
            data['first_name'],
            data['last_name'],
            data.get('role', 'member')
        )
        return success_response(message='Member added successfully')
    except Exception as e:
        return error_response(f'Failed to add member: {str(e)}', 500)

@startups_bp.route('/<int:startup_id>', methods=['DELETE'])
def delete_startup(startup_id):
    """Delete startup"""
    startup = Startup.query.get(startup_id)
    if not startup:
        return error_response('Startup not found', 404)
    
    try:
        db.session.delete(startup)
        db.session.commit()
        return success_response(message='Startup deleted successfully')
    except Exception as e:
        db.session.rollback()
        return error_response(f'Failed to delete startup: {str(e)}', 500)