from flask import Blueprint, request, jsonify
from models.chatConversation import ChatConversation, conversation_participants
from models.chatMessage import ChatMessage
from app.extensions import db, socketio
from app.utils.helper import error_response, success_response, paginate
from services.realtime_service import RealtimeService
import logging

chat_bp = Blueprint('chat', __name__, url_prefix='/api/chat')

@chat_bp.route('/conversations', methods=['GET'])
def get_conversations():
    """Get user's conversations with timezone-converted previews"""
    user_id = request.args.get('user_id', type=int)
    if not user_id:
        return error_response('User ID is required', 400)
    
    # Get user object for timezone conversion
    from models.user import User
    user = User.query.get(user_id)
    if not user:
        return error_response('User not found', 404)
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    # Get user's conversations
    conversations = ChatConversation.query\
        .join(conversation_participants)\
        .filter(conversation_participants.c.user_id == user_id)\
        .filter(ChatConversation.is_active == True)\
        .order_by(ChatConversation.updated_at.desc())\
        .all()
    
    return success_response({
        'conversations': [conv.to_dict(for_user=user) for conv in conversations]
    })

@chat_bp.route('/conversations/<int:conversation_id>/messages', methods=['GET'])
def get_messages(conversation_id):
    """Get messages for conversation with timezone conversion"""
    user_id = request.args.get('user_id', type=int)
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)
    
    if not user_id:
        return error_response('User ID is required', 400)
    
    # Get user and conversation
    from models.user import User
    user = User.query.get(user_id)
    conversation = ChatConversation.query.get(conversation_id)
    
    if not user or not conversation:
        return error_response('User or conversation not found', 404)
    
    # Check if user is participant
    if not conversation.is_user_participant(user_id):
        return error_response('Access denied', 403)
    
    messages = conversation.get_messages_for_user(user, limit, offset)
    
    return success_response({
        'conversation': conversation.to_dict(for_user=user),
        'messages': messages
    })

@chat_bp.route('/conversations/<int:conversation_id>/messages', methods=['POST'])
def send_message(conversation_id):
    """Send new message with timezone handling and WebSocket emission"""
    data = request.get_json()
    
    required_fields = ['sender_id', 'content']
    if not all(field in data for field in required_fields):
        return error_response('Missing required fields: sender_id, content')
    
    # Get user and conversation
    from models.user import User
    user = User.query.get(data['sender_id'])
    conversation = ChatConversation.query.get(conversation_id)
    
    if not user or not conversation:
        return error_response('User or conversation not found', 404)
    
    # Check if user is participant
    if not conversation.is_user_participant(user.id):
        return error_response('Access denied', 403)
    
    try:
        message = conversation.add_message(
            sender=user,
            content=data['content'],
            message_type=data.get('message_type', 'text'),
            metadata=data.get('metadata'),
            reply_to_id=data.get('reply_to_id')
        )
        
        # Emit real-time event to all participants
        RealtimeService.emit_new_message(message.id)
        
        # Prepare response with timezone-converted content
        response_data = message.to_dict(for_user=user)
        
        return success_response({
            'message': response_data
        }, 'Message sent successfully', 201)
    
    except Exception as e:
        db.session.rollback()
        return error_response(f'Failed to send message: {str(e)}', 500)

@chat_bp.route('/messages/<int:message_id>', methods=['GET'])
def get_message(message_id):
    """Get specific message with timezone conversion"""
    user_id = request.args.get('user_id', type=int)
    
    if not user_id:
        return error_response('User ID is required', 400)
    
    from models.user import User
    user = User.query.get(user_id)
    message = ChatMessage.query.get(message_id)
    
    if not user or not message:
        return error_response('User or message not found', 404)
    
    # Check if user is participant in conversation
    if not message.conversation.is_user_participant(user_id):
        return error_response('Access denied', 403)
    
    return success_response({
        'message': message.to_dict(for_user=user)
    })

@chat_bp.route('/messages/<int:message_id>', methods=['PUT'])
def edit_message(message_id):
    """Edit message content with WebSocket emission"""
    data = request.get_json()
    new_content = data.get('content')
    user_id = data.get('user_id')
    
    if not new_content or not user_id:
        return error_response('Content and user_id are required', 400)
    
    message = ChatMessage.query.get(message_id)
    if not message:
        return error_response('Message not found', 404)
    
    # Check if user is the sender
    if message.sender_id != user_id:
        return error_response('Can only edit your own messages', 403)
    
    try:
        message.edit_message(new_content)
        
        # Emit real-time edit event
        RealtimeService.emit_message_edited(message.id)
        
        return success_response({
            'message': message.to_dict()
        }, 'Message updated successfully')
    except Exception as e:
        db.session.rollback()
        return error_response(f'Failed to edit message: {str(e)}', 500)

@chat_bp.route('/conversations', methods=['POST'])
def create_conversation():
    """Create new conversation with WebSocket emission"""
    data = request.get_json()
    
    required_fields = ['created_by_id', 'participant_ids']
    if not all(field in data for field in required_fields):
        return error_response('Missing required fields: created_by_id, participant_ids')
    
    from models.user import User
    creator = User.query.get(data['created_by_id'])
    if not creator:
        return error_response('Creator not found', 404)
    
    try:
        # Create conversation
        conversation = ChatConversation(
            name=data.get('name'),
            conversation_type=data.get('conversation_type', 'direct'),
            created_by_id=creator.id,
            description=data.get('description'),
            avatar_url=data.get('avatar_url')
        )
        
        db.session.add(conversation)
        db.session.flush()  # Get the ID without committing
        
        # Add participants using the helper method
        participant_ids = data['participant_ids']
        participants = User.query.filter(User.id.in_(participant_ids)).all()
        
        # Add creator as admin
        conversation.add_participant(creator, 'admin')
        
        # Add other participants
        for participant in participants:
            if participant.id != creator.id:
                conversation.add_participant(participant, 'member')
        
        db.session.commit()
        
        # Emit real-time event
        RealtimeService.emit_conversation_created(conversation.id, creator.id)
        
        return success_response({
            'conversation': conversation.to_dict(for_user=creator)
        }, 'Conversation created successfully', 201)
    
    except Exception as e:
        db.session.rollback()
        return error_response(f'Failed to create conversation: {str(e)}', 500)

@chat_bp.route('/conversations/<int:conversation_id>/participants', methods=['POST'])
def add_participant(conversation_id):
    """Add participant to conversation"""
    data = request.get_json()
    user_id = data.get('user_id')
    role = data.get('role', 'member')
    
    if not user_id:
        return error_response('User ID is required', 400)
    
    from models.user import User
    user = User.query.get(user_id)
    conversation = ChatConversation.query.get(conversation_id)
    
    if not user or not conversation:
        return error_response('User or conversation not found', 404)
    
    try:
        conversation.add_participant(user, role)
        return success_response(message='Participant added successfully')
    except Exception as e:
        return error_response(f'Failed to add participant: {str(e)}', 500)

@chat_bp.route('/conversations/<int:conversation_id>/participants/<int:user_id>', methods=['DELETE'])
def remove_participant(conversation_id, user_id):
    """Remove participant from conversation"""
    from models.user import User
    user = User.query.get(user_id)
    conversation = ChatConversation.query.get(conversation_id)
    
    if not user or not conversation:
        return error_response('User or conversation not found', 404)
    
    try:
        conversation.remove_participant(user)
        return success_response(message='Participant removed successfully')
    except Exception as e:
        return error_response(f'Failed to remove participant: {str(e)}', 500)

@chat_bp.route('/conversations/<int:conversation_id>', methods=['DELETE'])
def delete_conversation(conversation_id):
    """Delete conversation (soft delete)"""
    conversation = ChatConversation.query.get(conversation_id)
    if not conversation:
        return error_response('Conversation not found', 404)
    
    try:
        conversation.is_active = False
        db.session.commit()
        return success_response(message='Conversation deleted successfully')
    except Exception as e:
        db.session.rollback()
        return error_response(f'Failed to delete conversation: {str(e)}', 500)

# WebSocket event handlers
@socketio.on('start_typing')
def handle_start_typing(data):
    """Handle typing start event"""
    conversation_id = data.get('conversation_id')
    user_id = data.get('user_id')
    
    if conversation_id and user_id:
        RealtimeService.emit_user_typing(conversation_id, user_id, True)

@socketio.on('stop_typing')
def handle_stop_typing(data):
    """Handle typing stop event"""
    conversation_id = data.get('conversation_id')
    user_id = data.get('user_id')
    
    if conversation_id and user_id:
        RealtimeService.emit_user_typing(conversation_id, user_id, False)

@socketio.on('mark_message_read')
def handle_mark_message_read(data):
    """Handle message read event"""
    conversation_id = data.get('conversation_id')
    user_id = data.get('user_id')
    message_id = data.get('message_id')
    
    if conversation_id and user_id and message_id:
        # Update read status in database (you might want to create a read_receipts table)
        RealtimeService.emit_message_read(conversation_id, user_id, message_id)

@socketio.on('join_user_conversations')
def handle_join_user_conversations(data):
    """Join all user's conversation rooms"""
    user_id = data.get('user_id')
    
    if user_id:
        from models.chatConversation import ChatConversation, conversation_participants
        
        # Get all user's conversations
        conversations = ChatConversation.query\
            .join(conversation_participants)\
            .filter(conversation_participants.c.user_id == user_id)\
            .filter(ChatConversation.is_active == True)\
            .all()
        
        # Join each conversation room
        for conversation in conversations:
            room_name = f'conversation_{conversation.id}'
            socketio.server.enter_room(request.sid, room_name)
        
        logging.info(f'User {user_id} joined {len(conversations)} conversation rooms')

@socketio.on('join_conversation')
def handle_join_conversation(data):
    """Join a specific conversation room"""
    conversation_id = data.get('conversation_id')
    user_id = data.get('user_id')
    
    if conversation_id and user_id:
        room_name = f'conversation_{conversation_id}'
        socketio.server.enter_room(request.sid, room_name)
        logging.info(f'User {user_id} joined conversation room {conversation_id}')

@socketio.on('leave_conversation')
def handle_leave_conversation(data):
    """Leave a conversation room"""
    conversation_id = data.get('conversation_id')
    user_id = data.get('user_id')
    
    if conversation_id and user_id:
        room_name = f'conversation_{conversation_id}'
        socketio.server.leave_room(request.sid, room_name)
        logging.info(f'User {user_id} left conversation room {conversation_id}')