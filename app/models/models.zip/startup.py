from datetime import datetime
from app.extensions import db
from sqlalchemy import Enum, JSON
from .Enums import StartupStage

class Startup(db.Model):
    __tablename__ = 'startups'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False)
    industry = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(255))
    description = db.Column(db.Text)
    stage = db.Column(Enum(StartupStage), default=StartupStage.idea)
    
    logo_data = db.Column(db.LargeBinary)
    logo_content_type = db.Column(db.String(100))
    banner_data = db.Column(db.LargeBinary)
    banner_content_type = db.Column(db.String(100))
    
    positions = db.Column(db.Integer, default=0)
    roles = db.Column(JSON, default={})
    
    creator_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    creator_first_name = db.Column(db.String(100))
    creator_last_name = db.Column(db.String(100))
    
    status = db.Column(db.String(50), default='active')
    member_count = db.Column(db.Integer, default=1)
    views = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    members = db.relationship('StartupMember', backref='startup', lazy='dynamic', cascade='all, delete-orphan')
    join_requests = db.relationship('JoinRequest', backref='startup', lazy='dynamic', cascade='all, delete-orphan')
    creator_user = db.relationship('User', backref='created_startups', foreign_keys=[creator_id])

    # HELPER FUNCTIONS
    
    def increment_views(self):
        """Increment view count"""
        self.views += 1
        db.session.commit()
    
    def update_member_count(self):
        """Update member count based on active members"""
        active_members = self.members.filter_by(is_active=True).count()
        self.member_count = active_members
        db.session.commit()
    
    def add_member(self, user_id, first_name, last_name, role='member'):
        """Add a new member to the startup"""
        from models.startUpMember import StartupMember
        
        member = StartupMember(
            startup_id=self.id,
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            role=role
        )
        db.session.add(member)
        self.update_member_count()
    
    def remove_member(self, user_id):
        """Remove a member from the startup"""
        member = self.members.filter_by(user_id=user_id, is_active=True).first()
        if member:
            member.is_active = False
            self.update_member_count()
    
    def update_stage(self, new_stage):
        """Update startup stage"""
        self.stage = StartupStage(new_stage)
        db.session.commit()
    
    def add_position(self, role_name, count=1):
        """Add available positions"""
        if role_name not in self.roles:
            self.roles[role_name] = 0
        self.roles[role_name] += count
        self.positions += count
        db.session.commit()
    
    def fill_position(self, role_name):
        """Fill an available position"""
        if role_name in self.roles and self.roles[role_name] > 0:
            self.roles[role_name] -= 1
            self.positions -= 1
            db.session.commit()
    
    def get_active_members(self):
        """Get list of active members"""
        return self.members.filter_by(is_active=True).all()
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'industry': self.industry,
            'location': self.location,
            'description': self.description,
            'stage': self.stage.value,
            'positions': self.positions,
            'roles': self.roles or [],
            'creator': {
                'id': self.creator_id,
                'firstName': self.creator_first_name,
                'lastName': self.creator_last_name
            },
            'status': self.status,
            'memberCount': self.member_count,
            'views': self.views,
            'createdAt': self.created_at.isoformat(),
            'updatedAt': self.updated_at.isoformat()
        }
