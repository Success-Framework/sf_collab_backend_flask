from datetime import datetime
from app.extensions import db
from sqlalchemy import JSON
from .chatMessage import ChatMessage

class ChatConversation(db.Model):
    __tablename__ = 'chat_conversations'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=True)  # For group chats
    conversation_type = db.Column(db.String(20), default='direct')  # direct, group
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Group chat properties
    description = db.Column(db.Text, nullable=True)
    avatar_url = db.Column(db.String(500), nullable=True)
    
    # Settings
    is_active = db.Column(db.Boolean, default=True)
    settings = db.Column(JSON, default={})  # Notification settings, etc.
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    created_by = db.relationship('User', backref='created_conversations', foreign_keys=[created_by_id])
    participants = db.relationship('User', secondary='conversation_participants', backref='conversations')
    messages = db.relationship('ChatMessage', backref='conversation', lazy='dynamic', cascade='all, delete-orphan')
    
    # HELPER FUNCTIONS
    
    def add_participant(self, user, role='member'):
        """Add participant to conversation"""
        from sqlalchemy import insert
        
        # Check if user is already a participant
        existing = db.session.execute(
            conversation_participants.select().where(
                conversation_participants.c.conversation_id == self.id,
                conversation_participants.c.user_id == user.id
            )
        ).first()
        
        if not existing:
            stmt = conversation_participants.insert().values(
                conversation_id=self.id,
                user_id=user.id,
                role=role
            )
            db.session.execute(stmt)
            db.session.commit()
    
    def remove_participant(self, user):
        """Remove participant from conversation"""
        stmt = conversation_participants.delete().where(
            conversation_participants.c.conversation_id == self.id,
            conversation_participants.c.user_id == user.id
        )
        db.session.execute(stmt)
        db.session.commit()
    
    def get_participant_role(self, user):
        """Get participant role in conversation"""
        result = db.session.execute(
            conversation_participants.select().where(
                conversation_participants.c.conversation_id == self.id,
                conversation_participants.c.user_id == user.id
            )
        ).first()
        
        return result.role if result else None
    
    def get_messages_for_user(self, user, limit=50, offset=0):
        """Get messages for specific user with timezone conversion"""
        messages = self.messages.order_by(ChatMessage.created_at.desc())\
                               .limit(limit)\
                               .offset(offset)\
                               .all()
        
        # Convert messages for user's timezone
        converted_messages = []
        for message in reversed(messages):  # Reverse to get chronological order
            converted_messages.append(message.to_dict(for_user=user))
        
        return converted_messages
    
    def get_last_message_preview(self, for_user=None):
        """Get last message preview with timezone conversion"""
        last_message = self.messages.order_by(ChatMessage.created_at.desc()).first()
        if last_message:
            preview = {
                'content': last_message.get_content_for_user(for_user) if for_user else last_message.prepare_for_sending(),
                'created_at': last_message.created_at,
                'sender_name': f"{last_message.sender.first_name} {last_message.sender.last_name}",
                'display_time': last_message.get_display_time_info(for_user) if for_user else None
            }
            return preview
        return None
    
    def add_message(self, sender, content, message_type='text', metadata=None, reply_to_id=None):
        """Add new message to conversation with timezone handling"""
        message = ChatMessage(
            conversation_id=self.id,
            sender_id=sender.id,
            original_content=content,
            message_type=message_type,
            metadata=metadata or {},
            reply_to_id=reply_to_id,
            sender_timezone=sender.get_timezone()
        )
        
        db.session.add(message)
        self.updated_at = datetime.utcnow()
        db.session.commit()
        
        return message
    
    def is_user_participant(self, user_id):
        """Check if user is a participant in this conversation"""
        return any(participant.id == user_id for participant in self.participants)
    
    def get_unread_message_count(self, user_id):
        """Get count of unread messages for user"""
        # This would require a read_receipts table in a real implementation
        # For now, return total message count
        return self.messages.count()
    
    def to_dict(self, for_user=None):
        """Convert conversation to dictionary with user-specific timezone"""
        data = {
            'id': self.id,
            'name': self.name,
            'conversation_type': self.conversation_type,
            'description': self.description,
            'avatar_url': self.avatar_url,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'participants': [{
                'id': user.id,
                'firstName': user.first_name,
                'lastName': user.last_name,
                'profilePicture': user.profile_picture,
                'timezone': user.get_timezone()
            } for user in self.participants],
            'last_message': self.get_last_message_preview(for_user),
            'message_count': self.messages.count(),
            'unread_count': self.get_unread_message_count(for_user.id) if for_user else 0
        }
        
        return data

# Association table for conversation participants
conversation_participants = db.Table('conversation_participants',
    db.Column('conversation_id', db.Integer, db.ForeignKey('chat_conversations.id'), primary_key=True),
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('joined_at', db.DateTime, default=datetime.utcnow),
    db.Column('role', db.String(20), default='member')  # member, admin
)