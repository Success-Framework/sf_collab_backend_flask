from datetime import datetime, timedelta
from sqlalchemy import Enum, JSON
from app.extensions import db
from .Enums import UserStatus, Privacy, Theme, EmailDigest
    
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password = db.Column(db.String(255), nullable=False)
    is_email_verified = db.Column(db.Boolean, default=False)
    last_login = db.Column(db.DateTime, nullable=True)
    status = db.Column(Enum(UserStatus), default=UserStatus.active)
    
    role = db.Column(db.String(50), default='member')  # member, admin, manager
    xp_points = db.Column(db.Integer, default=0)
    streak_days = db.Column(db.Integer, default=0)
    last_activity_date = db.Column(db.Date)
    
    # Computed/cached stats
    total_revenue = db.Column(db.Float, default=0.0)
    satisfaction_percentage = db.Column(db.Float, default=100.0)
    active_startups_count = db.Column(db.Integer, default=0)
    
    # Profile (stored as JSON)
    profile_picture = db.Column(db.String(500), nullable=True)
    profile_bio = db.Column(db.Text, nullable=True)
    profile_company = db.Column(db.String(255), nullable=True)
    profile_social_links = db.Column(JSON, default={})
    
    # Add location fields for timezone support
    profile_country = db.Column(db.String(100), nullable=True)
    profile_city = db.Column(db.String(100), nullable=True)
    profile_timezone = db.Column(db.String(50), nullable=True)
    
    # Preferences
    pref_email_notifications = db.Column(db.Boolean, default=True)
    pref_push_notifications = db.Column(db.Boolean, default=True)
    pref_privacy = db.Column(Enum(Privacy), default=Privacy.public)
    pref_language = db.Column(db.String(10), default='en')
    pref_timezone = db.Column(db.String(50), default='UTC')
    pref_theme = db.Column(Enum(Theme), default=Theme.light)
    
    # Notification Settings
    notif_new_comments = db.Column(db.Boolean, default=True)
    notif_new_likes = db.Column(db.Boolean, default=True)
    notif_new_suggestions = db.Column(db.Boolean, default=True)
    notif_join_requests = db.Column(db.Boolean, default=True)
    notif_approvals = db.Column(db.Boolean, default=True)
    notif_story_views = db.Column(db.Boolean, default=True)
    notif_post_engagement = db.Column(db.Boolean, default=True)
    notif_email_digest = db.Column(Enum(EmailDigest), default=EmailDigest.weekly)
    notif_quiet_hours_enabled = db.Column(db.Boolean, default=False)
    notif_quiet_hours_start = db.Column(db.String(5), default='22:00')
    notif_quiet_hours_end = db.Column(db.String(5), default='08:00')
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # ========== RELATIONSHIPS ==========
    
    # Core Authentication & Profile
    refresh_tokens = db.relationship('RefreshToken', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    notifications = db.relationship('Notification', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # Content Creation
    knowledge_posts = db.relationship('Knowledge', backref='author_user', lazy='dynamic', foreign_keys='Knowledge.author_id')
    ideas = db.relationship('Idea', backref='creator_user', lazy='dynamic', foreign_keys='Idea.creator_id')
    startups = db.relationship('Startup', backref='creator_user', lazy='dynamic', foreign_keys='Startup.creator_id')
    stories = db.relationship('Story', backref='author_user', lazy='dynamic', foreign_keys='Story.user_id')
    posts_list = db.relationship('Post', backref='author_user', lazy='dynamic', foreign_keys='Post.user_id')
    
    # Comments & Engagement
    idea_comments = db.relationship('IdeaComment', backref='author', lazy='dynamic', foreign_keys='IdeaComment.author_id')
    knowledge_comments = db.relationship('KnowledgeComment', backref='author', lazy='dynamic', foreign_keys='KnowledgeComment.author_id')
    post_comments_list = db.relationship('PostComment', backref='author', lazy='dynamic', foreign_keys='PostComment.author_id')
    
    # Likes & Bookmarks
    post_likes = db.relationship('PostLike', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    resource_likes = db.relationship('ResourceLike', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    startup_bookmarks = db.relationship('StartupBookmark', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    knowledge_bookmarks = db.relationship('KnowledgeBookmark', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # Tasks & Projects
    tasks = db.relationship('Task', backref='user', lazy='dynamic', foreign_keys='Task.user_id')
    created_tasks = db.relationship('Task', backref='creator_user', lazy='dynamic', foreign_keys='Task.created_by')
    assigned_tasks = db.relationship('Task', backref='assigned_user', lazy='dynamic', foreign_keys='Task.assigned_to')
    project_goals = db.relationship('ProjectGoal', backref='user', lazy='dynamic', foreign_keys='ProjectGoal.user_id')
    
    # Team & Startup Relationships
    startup_memberships = db.relationship('StartupMember', backref='user', lazy='dynamic', foreign_keys='StartupMember.user_id')
    join_requests = db.relationship('JoinRequest', backref='user', lazy='dynamic', foreign_keys='JoinRequest.user_id')
    reviewed_requests = db.relationship('JoinRequest', backref='reviewer', lazy='dynamic', foreign_keys='JoinRequest.reviewed_by')
    
    # Achievements & Growth
    user_achievements = db.relationship('UserAchievement', backref='user', lazy='dynamic', foreign_keys='UserAchievement.user_id')
    growth_metrics = db.relationship('GrowthMetric', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # Chat & Messaging
    sent_messages = db.relationship('ChatMessage', backref='sender', lazy='dynamic', foreign_keys='ChatMessage.sender_id')
    created_conversations = db.relationship('ChatConversation', backref='created_by', lazy='dynamic', foreign_keys='ChatConversation.created_by_id')
    conversations = db.relationship('ChatConversation', 
                                  secondary='conversation_participants', 
                                  backref=db.backref('participants', lazy='dynamic'))
    
    # Views & Analytics
    resource_views = db.relationship('ResourceView', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    story_views = db.relationship('StoryView', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # Downloads
    resource_downloads = db.relationship('ResourceDownload', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # Suggestions
    suggestions = db.relationship('Suggestion', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # Calendar Events
    calendar_events = db.relationship('CalendarEvent', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # Goal Milestones
    goal_milestones = db.relationship('GoalMilestone', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    # ========== HELPER FUNCTIONS ==========
    
    def update_last_activity(self):
        """Update last activity date and maintain streak"""
        today = datetime.utcnow().date()
        
        # If last activity was yesterday, increment streak
        if self.last_activity_date and self.last_activity_date == today - timedelta(days=1):
            self.streak_days += 1
        # If last activity was not today and not yesterday, reset streak
        elif self.last_activity_date != today:
            self.streak_days = 1
        
        self.last_activity_date = today
        self.last_login = datetime.utcnow()
        
        # Check streak achievements
        from services.achievement_service import AchievementService
        AchievementService.check_achievements(self.id, 'streak_days')
        
        db.session.commit()
    
    def add_xp_points(self, points: int):
        """Add XP points to user"""
        self.xp_points += points
        db.session.commit()
    
    def verify_email(self):
        """Mark user's email as verified"""
        self.is_email_verified = True
        db.session.commit()
    
    def update_profile(self, profile_data: dict):
        """Update user profile information"""
        if 'picture' in profile_data:
            self.profile_picture = profile_data['picture']
        if 'bio' in profile_data:
            self.profile_bio = profile_data['bio']
        if 'company' in profile_data:
            self.profile_company = profile_data['company']
        if 'socialLinks' in profile_data:
            self.profile_social_links = profile_data['socialLinks']
        if 'country' in profile_data:
            self.profile_country = profile_data['country']
        if 'city' in profile_data:
            self.profile_city = profile_data['city']
        if 'timezone' in profile_data:
            self.profile_timezone = profile_data['timezone']
            self.pref_timezone = profile_data['timezone']
        
        db.session.commit()
    
    def update_preferences(self, preferences_data: dict):
        """Update user preferences"""
        if 'emailNotifications' in preferences_data:
            self.pref_email_notifications = preferences_data['emailNotifications']
        if 'pushNotifications' in preferences_data:
            self.pref_push_notifications = preferences_data['pushNotifications']
        if 'privacy' in preferences_data:
            self.pref_privacy = Privacy(preferences_data['privacy'])
        if 'language' in preferences_data:
            self.pref_language = preferences_data['language']
        if 'timezone' in preferences_data:
            self.pref_timezone = preferences_data['timezone']
        if 'theme' in preferences_data:
            self.pref_theme = Theme(preferences_data['theme'])
        
        db.session.commit()
    
    def update_notification_settings(self, notification_data: dict):
        """Update notification settings"""
        if 'newComments' in notification_data:
            self.notif_new_comments = notification_data['newComments']
        if 'newLikes' in notification_data:
            self.notif_new_likes = notification_data['newLikes']
        if 'newSuggestions' in notification_data:
            self.notif_new_suggestions = notification_data['newSuggestions']
        if 'joinRequests' in notification_data:
            self.notif_join_requests = notification_data['joinRequests']
        if 'approvals' in notification_data:
            self.notif_approvals = notification_data['approvals']
        if 'storyViews' in notification_data:
            self.notif_story_views = notification_data['storyViews']
        if 'postEngagement' in notification_data:
            self.notif_post_engagement = notification_data['postEngagement']
        if 'emailDigest' in notification_data:
            self.notif_email_digest = EmailDigest(notification_data['emailDigest'])
        
        # Quiet hours settings
        if 'quietHours' in notification_data:
            quiet_hours = notification_data['quietHours']
            if 'enabled' in quiet_hours:
                self.notif_quiet_hours_enabled = quiet_hours['enabled']
            if 'start' in quiet_hours:
                self.notif_quiet_hours_start = quiet_hours['start']
            if 'end' in quiet_hours:
                self.notif_quiet_hours_end = quiet_hours['end']
        
        db.session.commit()
    
    def is_active(self):
        """Check if user is active"""
        return self.status == UserStatus.active
    
    def deactivate(self):
        """Deactivate user account"""
        self.status = UserStatus.inactive
        db.session.commit()
    
    def activate(self):
        """Activate user account"""
        self.status = UserStatus.active
        db.session.commit()
    
    def get_full_name(self):
        """Get user's full name"""
        return f"{self.first_name} {self.last_name}"
    
    def get_timezone(self):
        """Get user's timezone for message display"""
        from app.utils.timezone_converter import get_user_timezone
        return get_user_timezone(self)
    
    def get_statistics(self):
        """Get comprehensive user statistics"""
        return {
            'total_ideas': self.ideas.count(),
            'total_tasks': self.tasks.count(),
            'completed_tasks': self.tasks.filter_by(status='completed').count(),
            'total_startups': self.startups.count(),
            'total_achievements': self.user_achievements.filter_by(is_completed=True).count(),
            'total_comments': (self.idea_comments.count() + 
                             self.knowledge_comments.count() + 
                             self.post_comments.count()),
            'total_likes_received': self._calculate_total_likes_received(),
            'engagement_score': self._calculate_engagement_score()
        }
    
    def _calculate_total_likes_received(self):
        """Calculate total likes received on user's content"""
        total_likes = 0
        total_likes += sum(idea.likes for idea in self.ideas)
        total_likes += sum(knowledge.likes for knowledge in self.knowledge_posts)
        total_likes += sum(post.likes for post in self.posts)
        return total_likes
    
    def _calculate_engagement_score(self):
        """Calculate user engagement score (0-100)"""
        # This is a simplified engagement score calculation
        activities = (
            self.ideas.count() * 2 +
            self.tasks.filter_by(status='completed').count() * 1 +
            (self.idea_comments.count() + self.knowledge_comments.count() + self.post_comments.count()) * 1 +
            self._calculate_total_likes_received() * 0.5
        )
        
        # Normalize to 0-100 scale
        return min(activities / 10, 100)
    
    def get_recent_activity(self, limit=10):
        """Get user's recent activity across all platforms"""
        from models.task import Task
        from models.idea import Idea
        from models.ideaComment import IdeaComment
        
        activities = []
        
        # Recent ideas
        for idea in self.ideas.order_by(Idea.created_at.desc()).limit(5).all():
            activities.append({
                'type': 'idea_created',
                'title': idea.title,
                'timestamp': idea.created_at,
                'data': idea.to_dict()
            })
        
        # Recent tasks completed
        for task in self.tasks.filter_by(status='completed').order_by(Task.completed_date.desc()).limit(5).all():
            activities.append({
                'type': 'task_completed',
                'title': task.title,
                'timestamp': task.completed_date,
                'data': task.to_dict()
            })
        
        # Recent comments
        for comment in self.idea_comments.order_by(IdeaComment.created_at.desc()).limit(5).all():
            activities.append({
                'type': 'comment_made',
                'title': f'Comment on idea',
                'timestamp': comment.created_at,
                'data': comment.to_dict()
            })
        
        # Sort all activities by timestamp and return limited results
        activities.sort(key=lambda x: x['timestamp'], reverse=True)
        return activities[:limit]
    
    def to_dict(self, include_password=False, include_statistics=False, include_recent_activity=False):
        data = {
            'id': self.id,
            'firstName': self.first_name,
            'lastName': self.last_name,
            'email': self.email,
            'isEmailVerified': self.is_email_verified,
            'lastLogin': self.last_login.isoformat() if self.last_login else None,
            'status': self.status.value,
            'role': self.role,
            'xp_points': self.xp_points,
            'streak_days': self.streak_days,
            'last_activity_date': self.last_activity_date.isoformat() if self.last_activity_date else None,
            'total_revenue': self.total_revenue,
            'satisfaction_percentage': self.satisfaction_percentage,
            'active_startups_count': self.active_startups_count,
            'profile': {
                'picture': self.profile_picture,
                'bio': self.profile_bio,
                'company': self.profile_company,
                'socialLinks': self.profile_social_links or {},
                'country': self.profile_country,
                'city': self.profile_city,
                'timezone': self.profile_timezone
            },
            'preferences': {
                'emailNotifications': self.pref_email_notifications,
                'pushNotifications': self.pref_push_notifications,
                'privacy': self.pref_privacy.value,
                'language': self.pref_language,
                'timezone': self.pref_timezone,
                'theme': self.pref_theme.value
            },
            'notificationSettings': {
                'newComments': self.notif_new_comments,
                'newLikes': self.notif_new_likes,
                'newSuggestions': self.notif_new_suggestions,
                'joinRequests': self.notif_join_requests,
                'approvals': self.notif_approvals,
                'storyViews': self.notif_story_views,
                'postEngagement': self.notif_post_engagement,
                'emailDigest': self.notif_email_digest.value,
                'quietHours': {
                    'enabled': self.notif_quiet_hours_enabled,
                    'start': self.notif_quiet_hours_start,
                    'end': self.notif_quiet_hours_end
                }
            },
            'createdAt': self.created_at.isoformat(),
            'updatedAt': self.updated_at.isoformat(),
            'fullName': self.get_full_name(),
            'timezone': self.get_timezone()
        }
        
        if include_password:
            data['password'] = self.password
        
        if include_statistics:
            data['statistics'] = self.get_statistics()
        
        if include_recent_activity:
            data['recentActivity'] = self.get_recent_activity()
        
        return data