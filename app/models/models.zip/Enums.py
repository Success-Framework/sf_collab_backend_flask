# Enums
import enum

class UserStatus(enum.Enum):
    active = "active"
    deleted = "deleted"

class Privacy(enum.Enum):
    public = "public"
    private = "private"

class Theme(enum.Enum):
    light = "light"
    dark = "dark"

class EmailDigest(enum.Enum):
    daily = "daily"
    weekly = "weekly"
    monthly = "monthly"

class ResourceStatus(enum.Enum):
    active = "active"
    inactive = "inactive"

class SuggestionStatus(enum.Enum):
    pending = "pending"
    accepted = "accepted"
    rejected = "rejected"

class StartupStage(enum.Enum):
    idea = "idea"
    early = "early"
    growth = "growth"
    scale = "scale"

class JoinRequestStatus(enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"

class StoryType(enum.Enum):
    image = "image"
    video = "video"

class PostType(enum.Enum):
    professional = "professional"
    social = "social"
    image = "image"
    video = "video"

class ConnectionStatus(enum.Enum):
    connected = "connected"
    pending = "pending"
    blocked = "blocked"


