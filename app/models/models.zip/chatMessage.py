from datetime import datetime
from app.extensions import db
from sqlalchemy import JSON

class ChatMessage(db.Model):
    __tablename__ = 'chat_messages'
    
    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('chat_conversations.id'), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Store original message content without time conversion
    original_content = db.Column(db.Text, nullable=False)
    
    # Store sender's timezone for proper conversion
    sender_timezone = db.Column(db.String(50), default='UTC')
    
    # Message metadata
    message_type = db.Column(db.String(20), default='text')  # text, image, file, system
    metadata = db.Column(JSON, default={})  # For file URLs, image dimensions, etc.
    
    # Status tracking
    is_edited = db.Column(db.Boolean, default=False)
    edited_at = db.Column(db.DateTime, nullable=True)
    
    # Reply functionality
    reply_to_id = db.Column(db.Integer, db.ForeignKey('chat_messages.id'), nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sender = db.relationship('User', backref='sent_messages', foreign_keys=[sender_id])
    conversation = db.relationship('ChatConversation', backref='messages_list', foreign_keys=[conversation_id])
    reply_to = db.relationship('ChatMessage', remote_side=[id], backref='replies', foreign_keys=[reply_to_id])
    
    # HELPER FUNCTIONS
    
    def prepare_for_sending(self, sender_user=None):
        """Prepare message for sending by adding time placeholder"""
        from app.utils.timezone_converter import TimezoneConverter
        
        if sender_user:
            self.sender_timezone = sender_user.get_timezone()
        
        # Create time placeholder in sender's timezone
        time_placeholder = TimezoneConverter.create_time_placeholder(
            self.created_at, 
            self.sender_timezone
        )
        
        # Combine placeholder with original content
        return f"{time_placeholder} {self.original_content}"
    
    def get_content_for_user(self, user):
        """Get message content converted for specific user's timezone"""
        from app.utils.timezone_converter import TimezoneConverter
        
        user_tz = user.get_timezone()
        
        # Convert the time placeholder to user's timezone
        converted_content = TimezoneConverter.replace_time_placeholder_for_user(
            self.prepare_for_sending(),
            self.created_at,
            user_tz,
            self.sender_timezone
        )
        
        return converted_content
    
    def to_dict(self, for_user=None):
        """Convert message to dictionary, with timezone conversion if user provided"""
        base_data = {
            'id': self.id,
            'conversation_id': self.conversation_id,
            'sender_id': self.sender_id,
            'original_content': self.original_content,
            'message_type': self.message_type,
            'metadata': self.metadata or {},
            'is_edited': self.is_edited,
            'edited_at': self.edited_at.isoformat() if self.edited_at else None,
            'reply_to_id': self.reply_to_id,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'sender_timezone': self.sender_timezone
        }
        
        # If specific user provided, convert time for them
        if for_user:
            base_data['content'] = self.get_content_for_user(for_user)
            base_data['display_time'] = self.get_display_time_info(for_user)
        else:
            base_data['content'] = self.prepare_for_sending()
        
        # Include sender info if available
        if self.sender:
            base_data['sender'] = {
                'id': self.sender.id,
                'firstName': self.sender.first_name,
                'lastName': self.sender.last_name,
                'profilePicture': self.sender.profile_picture
            }
        
        # Include reply info if available
        if self.reply_to:
            base_data['reply_to'] = {
                'id': self.reply_to.id,
                'content': self.reply_to.original_content,
                'sender_id': self.reply_to.sender_id
            }
        
        return base_data
    
    def get_display_time_info(self, user):
        """Get comprehensive time display information for a user"""
        from app.utils.timezone_converter import TimezoneConverter
        user_tz = user.get_timezone()
        return TimezoneConverter.get_time_display_info(self.created_at, user_tz)
    
    def edit_message(self, new_content):
        """Edit message content"""
        self.original_content = new_content
        self.is_edited = True
        self.edited_at = datetime.utcnow()
        db.session.commit()
    
    def mark_as_read(self, user_id):
        """Mark message as read by user"""
        # This would require a read_receipts table in a real implementation
        # For now, this is a placeholder
        pass