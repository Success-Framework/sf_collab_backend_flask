from datetime import datetime
from app.extensions import db

class ResourceLike(db.Model):
    __tablename__ = 'resource_likes'
    
    id = db.Column(db.Integer, primary_key=True)
    resource_id = db.Column(db.Integer, db.ForeignKey('knowledge.id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    liked_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    resource = db.relationship('Knowledge', backref='likes_list', foreign_keys=[resource_id])
    user = db.relationship('User', backref='resource_likes_list', foreign_keys=[user_id])
    
    # HELPER FUNCTIONS
    
    def get_time_since_like(self):
        """Get time since like was created"""
        return datetime.utcnow() - self.liked_at
    
    def is_recent(self, minutes=30):
        """Check if like is recent"""
        time_diff = datetime.utcnow() - self.liked_at
        return time_diff.total_seconds() <= minutes * 60
    
    def get_resource_details(self):
        """Get resource details"""
        if self.resource:
            return {
                'title': self.resource.title,
                'category': self.resource.category,
                'author': f"{self.resource.author_first_name} {self.resource.author_last_name}",
                'likes_count': self.resource.likes
            }
        return None
    
    def to_dict(self):
        return {
            'id': self.id,
            'resource_id': self.resource_id,
            'user_id': self.user_id,
            'liked_at': self.liked_at.isoformat(),
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'time_since_like': str(self.get_time_since_like()),
            'is_recent': self.is_recent(),
            'resource': self.get_resource_details(),
            'user': {
                'id': self.user.id,
                'firstName': self.user.first_name,
                'lastName': self.user.last_name
            } if self.user else None
        }